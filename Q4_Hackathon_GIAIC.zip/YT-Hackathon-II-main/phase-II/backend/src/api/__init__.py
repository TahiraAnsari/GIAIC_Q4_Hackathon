"""API package."""
from src.api.routes import router as api_router

__all__ = ["api_router"]
