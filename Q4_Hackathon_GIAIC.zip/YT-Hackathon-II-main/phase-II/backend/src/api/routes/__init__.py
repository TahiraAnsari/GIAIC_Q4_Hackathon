"""API routes package."""
from src.api.routes.tasks import router

__all__ = ["router"]
