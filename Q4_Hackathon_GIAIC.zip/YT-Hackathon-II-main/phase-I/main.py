def main():
    print("Hello from hackathon-2-phase-i-youtube!")


if __name__ == "__main__":
    main()
